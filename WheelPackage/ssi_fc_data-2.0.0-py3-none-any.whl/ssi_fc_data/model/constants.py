AUTH_TOKEN = 'auth'
TWO_FA = '2fa'
OTHER = 'other'
NONE = None
ONE_WHITE_SPACE = ' '
EMPTY_STRING = ''


TOKEN_TYPE_ERROR_MESSAGE = 'Please select token type!'
CONNECTION_LOST_ERROR_MESSAGE = 'Connection lost: Try to reconnect to server!'
RECEIVE_ERROR_MESSAGE = 'Wrong format, message cannot be decoded!'